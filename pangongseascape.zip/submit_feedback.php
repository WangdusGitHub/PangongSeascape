<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $name = $_POST["name"];
    $email = $_POST["email"];
    $rating = $_POST["rating"];
    $feedback = $_POST["feedback"];

    // Validate email (you can add more validation if needed)
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email address. Please enter a valid email.";
        exit;
    }

    // Prepare email content
    $subject = "Feedback from $name";
    $message = "Name: $name\n";
    $message .= "Email: $email\n";
    $message .= "Rating: $rating\n";
    $message .= "Feedback/Comment:\n$feedback";

    // Set recipient email address
    $to = "your@email.com"; // Replace with your actual email address

    // Send email
    if (mail($to, $subject, $message)) {
        echo "Thank you for your feedback! We'll get back to you soon.";
    } else {
        echo "Oops! Something went wrong. Please try again later.";
    }
} else {
    echo "Invalid request.";
}
?>
